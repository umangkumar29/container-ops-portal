import type { ContainerStatus } from '../components/StatusBadge';

export interface Environment {
  id: string;
  name: string;
  type: 'PROD' | 'QA' | 'DEV' | 'INTEGRATION';
  resourceGroup: string;
  frontend: {
    name: string;
    status: ContainerStatus;
  };
  backend: {
    name: string;
    status: ContainerStatus;
  };
  costToday: number;
  mtdCost: number;
  lastRestart: string;
  costTrend: number; // Weekly trend percentage (positive = increase, negative = decrease)
  history: {
    date: string;
    cost: number;
  }[];
  breakdown: {
    frontend: number;
    backend: number;
  };
}

function generateHistory(baseCost: number, variance: number, days = 30) {
  return Array.from({ length: days }, (_, i) => ({
    date: new Date(Date.now() - (days - 1 - i) * 24 * 60 * 60 * 1000)
      .toISOString()
      .split('T')[0],
    cost: Math.round((baseCost + (Math.random() - 0.5) * 2 * variance) * 100) / 100,
  }));
}

export const environments: Environment[] = [
  {
    id: '1',
    name: 'KPIT GM QA',
    type: 'QA',
    resourceGroup: 'rg-kpit-gm-qa',
    frontend: {
      name: 'kpit-gm-qa-frontend',
      status: 'Running',
    },
    backend: {
      name: 'kpit-gm-qa-backend',
      status: 'Running',
    },
    costToday: 452.5,
    mtdCost: 12580,
    lastRestart: 'Today at 11:30',
    costTrend: 5.2,
    history: generateHistory(420, 60),
    breakdown: { frontend: 60, backend: 40 },
  },
  {
    id: '2',
    name: 'KPIT GM Production',
    type: 'PROD',
    resourceGroup: 'rg-kpit-gm-prod',
    frontend: {
      name: 'kpit-gm-prod-frontend',
      status: 'Running',
    },
    backend: {
      name: 'kpit-gm-prod-backend',
      status: 'Running',
    },
    costToday: 1254.75,
    mtdCost: 45200,
    lastRestart: 'Yesterday at 02:00',
    costTrend: -2.1,
    history: generateHistory(1180, 180),
    breakdown: { frontend: 45, backend: 55 },
  },
  {
    id: '3',
    name: 'Client Test Environment',
    type: 'INTEGRATION',
    resourceGroup: 'rg-client-test',
    frontend: {
      name: 'client-test-frontend',
      status: 'Starting',
    },
    backend: {
      name: 'client-test-backend',
      status: 'Running',
    },
    costToday: 321.1,
    mtdCost: 8940,
    lastRestart: 'Today at 09:15',
    costTrend: 12.5,
    history: generateHistory(290, 55),
    breakdown: { frontend: 70, backend: 30 },
  },
  {
    id: '4',
    name: 'Dev Sandbox',
    type: 'DEV',
    resourceGroup: 'rg-dev-sandbox',
    frontend: {
      name: 'dev-sandbox-frontend',
      status: 'Running',
    },
    backend: {
      name: 'dev-sandbox-backend',
      status: 'Error',
    },
    costToday: 148.25,
    mtdCost: 3180,
    lastRestart: '2 days ago',
    costTrend: 0.5,
    history: generateHistory(145, 25),
    breakdown: { frontend: 50, backend: 50 },
  },
  {
    id: '5',
    name: 'KPIT Staging',
    type: 'QA',
    resourceGroup: 'rg-kpit-staging',
    frontend: {
      name: 'kpit-staging-frontend',
      status: 'Running',
    },
    backend: {
      name: 'kpit-staging-backend',
      status: 'Running',
    },
    costToday: 685.0,
    mtdCost: 19400,
    lastRestart: 'Today at 06:00',
    costTrend: -1.4,
    history: generateHistory(640, 80),
    breakdown: { frontend: 55, backend: 45 },
  },
  {
    id: '6',
    name: 'Integration Testing',
    type: 'INTEGRATION',
    resourceGroup: 'rg-integration-test',
    frontend: {
      name: 'integration-frontend',
      status: 'Running',
    },
    backend: {
      name: 'integration-backend',
      status: 'Starting',
    },
    costToday: 218.9,
    mtdCost: 6120,
    lastRestart: '3 hours ago',
    costTrend: 7.8,
    history: generateHistory(200, 40),
    breakdown: { frontend: 65, backend: 35 },
  },
];
